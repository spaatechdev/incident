import collections

x=collections.namedtuple()
