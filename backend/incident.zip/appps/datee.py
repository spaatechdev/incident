from datetime import datetime, timedelta
print(datetime.now().time().replace(microsecond=0))
