import React from "react";
import incidentpic from "../../../../Images/IncidentPic.jpeg";
import "../../../../CSS/Image.css";

const ImageFunc = () => {
	return (
		<div>
			<img src={incidentpic} />
			{/* <CDBSidebar textColor="#fff" backgroundColor="#333">
				<CDBSidebarHeader prefix={<CDBIcon icon="bars" size="lg" />}>
					Contrast Multi Level
				</CDBSidebarHeader>
				<CDBSidebarContent>
					<CDBSidebarMenu>
						<CDBSidebarSubMenu title="Sidemenu" icon="th">
							<CDBSidebarMenuItem> submenu 1</CDBSidebarMenuItem>
							<CDBSidebarMenuItem> submenu 2</CDBSidebarMenuItem>
							<CDBSidebarMenuItem> submenu 3</CDBSidebarMenuItem>
						</CDBSidebarSubMenu>
					</CDBSidebarMenu>
				</CDBSidebarContent>

			</CDBSidebar> */}
		</div>
	);
};
export default ImageFunc;
